﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FavoriteService.Migrations
{
    /// <inheritdoc />
    public partial class AddUniqueConstraintToFavorites : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Favorites_BookId_Username",
                table: "Favorites",
                columns: new[] { "BookId", "Username" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Favorites_BookId_Username",
                table: "Favorites");
        }
    }
}
